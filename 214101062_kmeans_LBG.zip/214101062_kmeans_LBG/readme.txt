Instruction to execute the code:

1)Provide complete path of the input file in fopen() statement(replace all single backslash(\) with double blackslash(\\) so that no problem occurs when reading the file ,else you may get an error of STR!=NULL).
