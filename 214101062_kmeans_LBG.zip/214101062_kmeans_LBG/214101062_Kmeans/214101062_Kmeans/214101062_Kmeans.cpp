// 214101062_Kmeans.cpp : Defines the entry point for the console application.


//Header filed included
#include "stdafx.h"       
#include <iostream>
#include <cmath>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>
#include<float.h>
using namespace std;


long double delta = 0.0001;   // Delta value
vector<vector<int>> assignedR;
long double Weight[12] = {1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0};   //Given Tokhura Weights.

//Function to calculate Tokhura distance
long double Tokhura(vector<long double>&currentU,vector<long double> &currrentC)
{
	long double sum=0;
	for(int i=0;i<12;i++)
	{
		long double x=currrentC[i]-currentU[i];
		sum+=(Weight[i]*(x*x));
	}
	return sum;
}



//Function to assign regions for all vectors 
void Assignreg(vector<vector<long double>> &universe,vector<vector<long double>> &codebook)
{
	int rows=universe.size();
	for(int i=0;i<rows;i++)
	{
		int row=0;
		vector<long double>currentU = universe[i];
		long double minD=LDBL_MAX;
		for(int j=0;j<8;j++)
		{
			vector<long double> currrentC=codebook[j];
			long double distance=Tokhura(currentU,currrentC);
			if(distance<minD)
			{
				minD=distance;
				row=j;
			}
		}
		assignedR[row].push_back(i);
	}
	return;
}

//function to calculate Distortion for universe and codebook
long double Distortion(vector<vector<long double>> &universe,vector<vector<long double>> &codebook)
{
	int index=0;
	long double sum=0;
	long double D=0;
	for(int i=0;i<8;i++)
	{
		int row=assignedR[i].size();
	    sum+=long double(row);
		for(int j=0;j<row;j++)
		{
			index=assignedR[i][j];
			D+=Tokhura(universe[index],codebook[i]);//Calculating Tokhura Distance
		}
		
	}
	D/=sum;
	return D;
}

//update the codebook regions
void Update(vector<vector<long double>> &universe,vector<vector<long double>> &codebook)
{
    for(int i=0;i<8;i++){
		vector<long double> temp(12, 0.0);
		int size = assignedR[i].size();
		for(int j=0;j<size;j++){
			int index = assignedR[i][j];
			for(int k=0;k<12;k++){
				temp[k] += universe[index][k];
			}
		}
		for(int j=0;j<12;j++){
			codebook[i][j] = temp[j]/((long double)size);            // Calculating the centroid and updating the region vector values.
		}
	}
	return;
}


//k means algorithm
void Kmeans(vector<vector<long double>> &universe,vector<vector<long double>> &codebook)
{
	long double d=0;
	Assignreg(universe,codebook);
	long double D=Distortion(universe,codebook);
	int m=0;
	cout<<"Total Distortion in Cycle "<<m+1<<": "<<D<<" Distortion Change: "<<fixed<<setprecision(6)<<abs(D-d)<<endl;
	while(abs(D-d)>delta)
	{
		Update(universe,codebook);
		assignedR.clear();
		assignedR.resize(8);
		Assignreg(universe,codebook);
		d=D;
		D=Distortion(universe,codebook);
		m++;
		cout<<"Total Distortion in Cycle "<<m+1<<": "<<D<<" Distortion Change: "<<fixed<<setprecision(6)<<abs(D-d)<<endl;
	}
	return;
}




int _tmain(int argc, _TCHAR* argv[]) 
{
	fstream fin;
	fin.open("C:\\Users\\rmkis\\Downloads\\Universe\\Universe.csv");
	vector<vector<long double>> universe;
	vector<vector<long double>> codebook;
	char delimeter;
	long double ci;
	assignedR.clear();
    assignedR.resize(8);
	while(fin>>ci)
	{
		vector<long double>temp;
		temp.push_back(long double(ci));
		for(int i=1;i<=11;i++)
		{
		   fin>>delimeter>>ci;
			temp.push_back(long double(ci));
		}
		universe.push_back(temp);
	}
	fin.close();
	//now universe vector consists of Ci values of csv file
	int no_of_regions=universe.size()/8;
	for(int i=0;i<8;i++)
	{
		int region=i*no_of_regions;
		codebook.push_back(universe[region]);
	}
	//codebook is filled with vectors
	Kmeans(universe,codebook);
	//Printing the Final Codebook
	cout<<"Final Codebook:\n";
	int row = codebook.size();
	int col = codebook[0].size();
	for(int i=0;i<row;i++)
	{
		for(int j=0;j<col;j++)
		{
			
			cout<<fixed<<setprecision(6)<<codebook[i][j]<<" ";
		}
		cout<<fixed<<setprecision(6)<<endl;
		
	}
	system("PAUSE");
	return 0;
}
