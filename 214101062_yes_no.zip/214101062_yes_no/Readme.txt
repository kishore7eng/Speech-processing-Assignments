Instruction to execute the code:
1)Record a single word (YES or NO) and save it as a .txt file in any folder.
2)My code is written on basis of assumption that Input file consists Header in it, so please use files with HEADER as input.
3)Provide complete path of the input file in fopen() statement(replace all single backslash(\) with double blackslash(\\) so that no problem occurs when reading the file ,else you may get an error of STR!=NULL).

Implementation:
1)Reading the input file.
2)Before doing any analysis we have to do 2 important steps:
      i)Correct DC shift .
     ii)Do normalization to +/-5000  by the formula (X_i-DCshift)*Normalization factor where X_i is i'th value of input file
3)Write normalized values in a seperate file.
4)Calculate Energy and ZCr.
5)Enery can be calculated by Energy+X_i*X_i where X_i is the i'th normalized value.
6)ZCR is calculated whenever the waves hit 0th line of X axis.
7)These values are stored in Output file.
8)Next is to find the average enery of noise to differentiate between fricatives, vowels and noise.
9)If energy levels of successive frames are rising the mark it as starting point.
10)If energy levels of successive frames are lowering the mark it as ending point.
11)Next is to find the average ZCR value from starting point to ending point.
12)If average ZCR value is greater than 20 it is Fricatives  that is YES.
13) If average ZCR value is lesser than 20 it is Vowel  that is NO.
14)CLose all opened files.
