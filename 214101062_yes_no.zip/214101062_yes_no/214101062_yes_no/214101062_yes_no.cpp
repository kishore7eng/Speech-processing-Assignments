// YesorNo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<ctype.h>
#include<cstdio>
//Below function is to reduce DC shift to +/- 5000 and do normalization
long findMaximum(FILE *input)
{
	char frame[100];
	int max_val=0,i=0;
	while(fgets(frame,sizeof(frame),input)!= NULL)//reding input
	{
		i++;
		if(i>5)//skipping header
		{
			int num=atoi(frame);
			if(abs(num)>max_val)
			{
				max_val=abs(num);//this whole loop finds maximum of all absolue values

			}
		}
     }
	return max_val;
}
//Below function is to reduce DC shift to +/- 5000 and do normalization
void normalize(FILE *input,FILE *output)
{
	long  max_val=0,DCS=0,no_of_samples=0,i=0;
	double norm_val=0,final_DCS=0;
	char frame[100];
	while(fgets(frame,sizeof(frame),input)!= NULL)//reading input from file
	{
		i++;
		if(i>5)//This is to skip the first five lines of the input file which is HEADER
		{
			long num=atoi(frame);//converting string to int for calculation purpose
			DCS=DCS+num;//summing up of all values
			no_of_samples++;//counting number of values
		}
	}
	i=0;
	rewind(input);//placing cursor at start of file

	printf("Number of samples : %ld\n",no_of_samples);//printing number of samples

	final_DCS=DCS/no_of_samples;//taking average of all samples
	printf("DC Shift: %lf\n",final_DCS);

	max_val=findMaximum(input);
    printf("Max Aplitude : %ld\n",max_val);
	rewind(input);

	norm_val=(max_val-5000)/(max_val*1.0);//calculating nomalization factor
	printf("Normalization Factor : %lf\n\n",norm_val);

	while(fgets(frame,sizeof(frame),input)!= NULL)
	{
		i++;
		if(i>5)//skipping Header
		{
			long num=atoi(frame);
			long final_norm_val=floor((num-final_DCS)*norm_val);

			if(labs(final_norm_val)>1)//avoiding unnecessary 0's,1's and -1's to be written in file
			{
				fprintf(output,"%ld\n",final_norm_val);//writing normalized values in seperate file
            }
		}

	}
	rewind(output);
    i=0;
	rewind(input);
}
//below function calculates the Energy and ZCR values
void E_ZCR_calc(FILE*input,FILE*output)
{
    rewind(input);
	char frame[100];
	double Energy=0,ZCR=0,count=0,prev=0;

	while(fgets(frame,sizeof(frame),input)!= NULL)
	{
        double num= atof(frame);//converting string to float

        if(count==100)//calculating Energy and ZCR values for each 100 samples
        {
            fprintf(output,"%lf  %lf\n",Energy/100.0,ZCR);//writing energy and ZCR values in output file
            Energy=0,count=0,ZCR=0;
        }
        Energy=Energy+num*num;//finding energy by squaring(to get all values in positive) and adding them together

        if(prev<0 && num>0)//if previous value is negative and current value is positive the ZCR is incremented
        {
            ZCR++;
        }
        else if(prev>0 && num<0)//if previous value is positive and current value is negative the ZCR is incremented
        {
            ZCR++;
        }
        count++;
        prev=num;
    }
}
//below function detects YES or NO using ZCR value
void detect_Y_N( double *ZCR,long start_point,long end_point)
{
	int no_of_frames=end_point-start_point+1,avg_ZCR=0;

    for(long i=start_point; i<=end_point-1; i++)//looping over starting point to ening point to find average ZCR
    {
        avg_ZCR=avg_ZCR+ZCR[i];//summing up of all ZCR values from start point to end point
	}
	avg_ZCR/=no_of_frames;//avg of ZCR values

	printf("Total frames : %d\n",no_of_frames);
	if(avg_ZCR> 20)//if average ZCR values from start point to end point is greater than 20 then it is fricative (yes)
    {
        printf("YES\n");
    }
	else//if average ZCR values from start point to end point is lesser than or equal to 20 then it is vowel(no)
    {
        printf("NO\n");
    }
}
int _tmain(int argc, _TCHAR* argv[])
{
	FILE *input,*output,*norm_input;

	printf("START\n" );
	char frame[100],*end1;
	//Opening required files
	fopen_s(&input,"E:\\New folder\\214101062_yes_no\\no3.txt","r");
	fopen_s(&output,"E:\\New folder\\214101062_yes_no\\output.txt","w+");
	fopen_s(&norm_input,"E:\\New folder\\214101062_yes_no\\norm_input.txt","w+");

	if(fgets(frame,sizeof(frame),input)==NULL)
	{
		printf("Empty Input File");//if input file is empty print empty file and exit 
		exit(1);
	}

	rewind(input);
	printf("FILE READ\n" );
	normalize(input,norm_input);//calling function to do DC shift reduction and normalization

	//craeting dynamic arrays to store Energy and ZCR values of samples
	double *Energy=new double[10000];
	double *ZCR=new double[10000];

	double E_threshold=0,ZCR_threshold=0;

	double val=0.0;
	long start_point=0,end_point=0,flag=0,no_of_frames=0;
	rewind(input);
	E_ZCR_calc(norm_input,output);//calling  function to calculate Energy and ZCR
    rewind(output);

	while(fgets(frame,sizeof(frame),output)!= NULL)//reading Energy and ZCR values stored in output file seperated by space
	{
		Energy[no_of_frames]=strtod(frame,&end1);//strtod convers str to double and return double value and a pointer pointing the next value of double 

		ZCR[no_of_frames]=strtod(end1,NULL);//here it coverts the ZCR value present from str to double and return NULL pointer 

		no_of_frames++;
	}
	rewind(output);


	for(int i=0; i<5; ++i)//finding Energy threshold of first 5 values so that Average Energy of noise can be found
    {
        E_threshold += Energy[i];
    
    }

    E_threshold =(E_threshold /5);
    double noise= E_threshold*3;

    for(int i=0; i<no_of_frames-3; i++)
    {
        if(!flag && Energy[i+1] > noise && Energy[i+2] > noise && Energy[i+3] > noise)//if successive energy are gtreater tha 3*noise then start point is marked
        {
            start_point = i,flag = 1;
            continue;
        }
        else if(flag && Energy[i+1] <noise&& Energy[i+2] < noise && Energy[i+3] < noise)//if successive energy are lesserer tha 3*noise then end point is marked
        {
            end_point = i,flag = 0;
            break;
        }
    }

    if(flag==1)
    {
        end_point=no_of_frames-3;//if no end point is found the the last frame -3 is marked as end point
    }

	//printing start point and end point and energy at those points
	printf("\n");
    printf("Frame starts from : %d\n",start_point);
    printf("Frame end on  : %d\n",end_point);
    printf("Energy at Starting point : %lf\n",Energy[start_point]);
	printf("Energy at ending point : %lf\n",Energy[end_point]);
    detect_Y_N(ZCR,start_point,end_point);//Deetecting yes/no using ZCR values
	printf("END");

	//closing all opened files
    fclose(input);
	fclose(output);
	fclose(norm_input);

    delete []Energy;
	delete []ZCR;
	getchar();
	return 0;
}

