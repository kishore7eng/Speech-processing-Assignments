#include "stdafx.h"
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<ctype.h>
#include<cstdio>
#include<float.h>
void write_norm(FILE *input,FILE *output,double norm_factor,double DCS)//writing normalization value to file
{
	char frame[100];
	rewind(input);
	while(!feof(input))
	{
		fgets(frame,sizeof(frame),input);
        double num=atof(frame);
        double final_norm_val=(num-DCS)*norm_factor;
        fprintf(output,"%lf\n",final_norm_val);
	}
}
double findmax(FILE *input)//finding maximum value to calculate normalization factor
{
	double max=0;
	char frame[100];
	rewind(input);
	while(!feof(input))
	{
		fgets(frame,sizeof(frame),input);
        double num=atof(frame);
        if(abs(num)>max)
        {
            max=abs(num);
        }
     }
	return max;
}
//normalization and DC shift
void normalize(FILE *input,FILE *output)
{
 
	double DCS=0,no_of_samples=0;
	double norm_val=0,final_DCS=0;
	char frame[100];
	rewind(input);
	while(!feof(input))
	{
		fgets(frame,sizeof(frame),input);
        double num=atof(frame);
        DCS=DCS+num;
        no_of_samples++;

	}

	rewind(input);
	final_DCS=DCS/no_of_samples;
	
	double max_val=findmax(input);
	norm_val=abs(max_val-5000)/(max_val*1.0);
	write_norm(input,output,norm_val,final_DCS);
	
	rewind(output);
	rewind(input);
}
//finding stable frames having max STE
void stable_frames(FILE *ip,double f[5][320])
{
    
    char frame[100];
    rewind(ip);
	double Energy[1000]={0},max=DBL_MIN, energy=0,temp[1000][320]={{0}};
    int no_of_frames=0,count=0,index=0;

    while(!feof(ip))
    {
		fgets(frame,sizeof(frame),ip);
        if(count>=320)
        {
            count=0;
            ++no_of_frames;//counting number of frames for a file
        }
        temp[no_of_frames][count]=atof(frame);
        count++;
        
	}
   //Energy calculation
    for(int i=0;i<no_of_frames;i++)
    {
        energy=0;
        for(int j=0;j<320;j++)
        {
            energy+=(temp[i][j]*temp[i][j]);
        }
        Energy[i]=energy/320*1.0;
    }
    //max energy calculation and stable part found
    for(int i=0;i<no_of_frames;i++)
    {
        if(Energy[i]>max)
        {
            max=Energy[i];
            index=i;
        }
    }
	
   
    int start=index-2,end=index+2,k=0;
    for(int i=start;i<=end;i++)
    {
        for(int j=0;j<320;j++)
        {
            f[k][j]=temp[i][j];
        }
		k++;
    }
}
//applying hamming window
void Hamming(double temp[][320])
{
    for(int i=0;i<5;i++)
    {
        for(int j=0;j<320;j++)
        {
            
            temp[i][j]*=(0.54-0.46*cos(7.28*int(temp[i][j])/319));

        }
	}
}
//calculating Ri values
void Ri(double temp[5][320],double ri[5][13])
{ 
    for(int i=0;i<5;i++)
    {
        for(int j=0;j<=12;j++)
        {
            for(int k=0;k<=319-j;k++)
            {
                ri[i][j]+=temp[i][k]*temp[i][k+j];
            }
        }

    }
    
}

//Ai value calculation
void Ai(double ri[5][13],double ai[5][13])
{
     
    for(int frame=0;frame<5;frame++)
    {

         double Ai[13][13]={{0}},e[13]={0},k[13]={0};
         e[0]=ri[frame][0];
         for(int i=1;i<=12;i++)
         {
              double sum=0;
              for(int j=1;j<=i-1;j++)
              {
                  sum=sum+(Ai[i-1][j]*ri[frame][i-j]);
              }

              k[i]=(ri[frame][i]-sum)/e[i-1];
              Ai[i][i]=k[i];

              for(int j=1;j<=i-1;j++)
              {
                  Ai[i][j]=Ai[i-1][j]-k[i]*Ai[i-1][i-j];
              }
              e[i]=(1-(k[i]*k[i]))*e[i-1];

          }
          for(int i=1;i<=12;i++)
          {
             ai[frame][i]=Ai[12][i];
          }
    }
    
}
//raised sin 
void raisedsin(double ci[5][13])
{
	for(int i=0;i<5;i++)
    {
        for(int j=1;j<=12;j++)
        {
            ci[i][j]*=(1+(12*1.0/2)*sin(3.14*j/12));
        }
    }
}
//ci value calculation
void Ci(double ri[5][13],double ai[5][13],double ci[5][13])
{
  
    for(int k=0;k<5;k++)
    {
         double sigma=ri[k][0];
         ci[k][0]=log10(sigma*sigma);
         for(int i=1;i<=12;i++)
         {
             double s=0;
             for(int j=1;j<=i-1;j++)
             {
                  s+=(j/(i*1.0))*ci[k][j]*ai[k][i-j];
             }
             ci[k][i]=s+ai[k][i];
         }
    }

	raisedsin(ci);  
}
//Tokhura distance calculation with given weights
double Tokhura(double c_i[5][13],double weights[12],FILE *ip)
{
	char frame[2048];
	double  ref[5][13]={{0}};
	int no_of_frames=0,count=0;

	while(!feof(ip) && count<5)
	{
		fgets(frame,sizeof(frame),ip);//reading 13 values of each row from file
		sscanf(frame,"%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf", &ref[count][0], &ref[count][1], &ref[count][2], &ref[count][3], &ref[count][4], &ref[count][5], &ref[count][6], &ref[count][7], &ref[count][8], &ref[count][9], &ref[count][10], &ref[count][11], &ref[count][12]);
		count++;
	}

	double dist=0;
	for(int i=0;i<5;i++)
	{
		double d=0;
		for(int j=1;j<=12;j++)
		{
			double diff=c_i[i][j]-ref[i][j];
			d+=weights[j-1]*diff*diff;
		}
		dist+=(d/12.0);
	}
	dist/=5.0;
	return dist;
}
//average Ci values calculation
void averageCi(double C_avg[5][13],double c[11][5][13])
{
   
    for(int i=0;i<5;i++)
    {
        for(int j=0;j<=12;j++)
        {
            
            for(int file=1;file<=10;file++)
            {
                C_avg[i][j]+=c[file][i][j];
            }
            C_avg[i][j]/=10.0;
           
        }
    }
}

int _tmain(int argc, _TCHAR* argv[])
{
    char vowel[5]={'a','e','i','o','u'};
    FILE *ip,*op_c,*op_norm,*ref_ip;
	double acc=0,accuracy=0;

	//TRAINING
    for(int vow=0;vow<5;vow++)
    {
		double c[11][5][13]={{{0}}},c_avg[5][13]={{0}};
        char fname[50];

        for(int file=1;file<=10;file++)//looping over 1 to 10 files for training
        {

		    double f[5][320]={{0}},r_i[5][13]={{0}},a_i[5][13]={{0}},c_i[5][13]={{0}};//initializing all arrays to 0
            char fpath[100] = "F:\\\\IITG\\\\SEM 1\\\\Speech processing\\\\Assignments\\\\214101062";
            char p[1000];

		    strcpy(p,fpath);
            sprintf(fname, "\\\\214101062_%c_%d.txt", vowel[vow], file);//writing file name to buffer
            strcat(p,fname);//concatenating exact path and file name 
            fopen_s(&ip,p,"r");
            fopen_s(&op_norm,"F:\\\\IITG\\\\SEM 1\\\\Speech processing\\\\Assignments\\\\214101062\\\\norm.txt","w+");

            normalize(ip,op_norm);//normalizing input file
            rewind(op_norm);
            stable_frames(op_norm,f);//finding stable part having high STE
			Hamming(f);//applying hamming window
            Ri(f,r_i);//calculating Ri values
			Ai(r_i,a_i);//calculating Ai values
            Ci(r_i,a_i,c_i);//calculating Ci values

			for(int m=0;m<5;m++)
			{
				for(int n=0;n<=12;n++)
				{
					c[file][m][n]=c_i[m][n];
				}
			}

			fclose(ip);
            fclose(op_norm);
		}

        averageCi(c_avg,c);//taking average Ci values for each vowel and storing it in a 3D array

        char rname[100];
        char rpath[100] = "F:\\\\IITG\\\\SEM 1\\\\Speech processing\\\\Assignments\\\\214101062";
		sprintf(rname,"\\\\ref%c.txt",vowel[vow]);
        strcat(rpath,rname);
        fopen_s(&op_c,rpath,"w+");

		//writing average Ci values to file
        for(int i=0; i<5; i++)
        {
            for(int j=0; j<12; j++)
			{
	         	   fprintf(op_c, "%lf,", c_avg[i][j]);
		    }
	   	fprintf(op_c, "%lf\n", c_avg[i][12]);
        }
		fclose(op_c);

	}

	//TESTING
	for(int vow=0;vow<5;vow++)
	{
		int flag=0;
		 char fpath[100] = "F:\\\\IITG\\\\SEM 1\\\\Speech processing\\\\Assignments\\\\214101062";
		for(int file=11;file<=20;file++)//looping from file 11 to 20 for testing
		{
			char fname[100];
			double weight[12] = {1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0}; 
	        double f[5][320]={{0}},r_i[5][13]={{0}},a_i[5][13]={{0}},c_i[5][13]={{0}};
            char p[1000];

		    strcpy(p,fpath);
            sprintf(fname, "\\\\214101062_%c_%d.txt", vowel[vow], file);
            strcat(p,fname);
           
            fopen_s(&ip,p,"r");
            fopen_s(&op_norm,"F:\\\\IITG\\\\SEM 1\\\\Speech processing\\\\Assignments\\\\214101062\\\\norm.txt","w+");

            normalize(ip,op_norm);     
            rewind(op_norm);
            stable_frames(op_norm,f);
            Hamming(f);
            Ri(f,r_i);
            Ai(r_i,a_i);
            Ci(r_i,a_i,c_i);


			fclose(ip);
            fclose(op_norm);


		    double tokhura_d=DBL_MAX,dist=0;
			char tokhura_vow;
			//Finding tokhura distance and predicting vowel
			for(int i=0;i<5;i++)
			{
				strcpy(p,fpath);
				sprintf(fname,"\\\\ref%c.txt",vowel[i]);
				strcat(p,fname);
				fopen_s(&ref_ip,p,"r");

				dist=Tokhura(c_i,weight,ref_ip);
				if(tokhura_d>dist)
				{
					tokhura_d=dist;
					tokhura_vow=vowel[i]; 
				}
			}
			
			fclose(ref_ip);
			printf("original Vowel: %c ||Tokhura Predicted Vowel: %c || Tokhura distance: %lf || \n", vowel[vow], tokhura_vow, tokhura_d);
			if(vowel[vow] == tokhura_vow) flag++;
        }
		acc=(flag/10.0)*100;
		accuracy+=acc;
    	printf("\n");
		printf("Tokhura Accuracy: %lf\n", acc);		
		printf("\n");
	}
	printf("Overall Accuracy: %lf\n",accuracy/5.0);
	system("pause");
    return 0;
}